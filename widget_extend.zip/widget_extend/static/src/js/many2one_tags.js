/**
 * Created by mihai on 15-10-23.
 */

(function(){
    openerp.web.form.Many2oneTags = openerp.web.form.AbstractField.extend(openerp.web.form.ReinitializeFieldMixin, {
        template: 'Many2oneTags',
        init: function(field_manager, node){
            this._super(field_manager, node);
            this.records_orderer = new openerp.web.DropMisordered();
            this.set("values", []);
            this.field_manager.on("view_content_has_changed", this, function() {
                var domain = new openerp.web.CompoundDomain(this.build_domain()).eval();
                if (! _.isEqual(domain, this.get("domain"))) {
                    this.set("domain", domain);
                }
            });
        },
        initialize_field: function() {
            openerp.web.form.ReinitializeFieldMixin.initialize_field.call(this);
            this.on("change:domain", this, this.query_values);
            this.set("domain", new openerp.web.CompoundDomain(this.build_domain()).eval());
            this.on("change:values", this, this.render_value);
        },
        query_values: function() {
            var def;
            var self = this;
            if(this.field.type == "many2one") {
                var model = new openerp.Model(openerp.session, this.field.relation);
                def = model.call("name_search", ['', this.get("domain")], {"context": this.build_context()});
            } else {
                var values = _.reject(this.field.selection, function(v){
                    return v[0] === false && v[1] === '';
                });
                def = $.when(values);
            }
            this.records_orderer.add(def).then(function(values){
                if(!_.isEqual(values, self.get("values"))){
                    self.set("values", values);
                }
            });
        },

        render_value: function() {
            var self = this;
            var values = this.get("values");

            var str = "";
            var selected_str = "";

            for(var i=0; i<values.length; i++){
                if (_.isEqual(this.get("value"), values[i][0])){
                    str += "<li data-value='"+values[i][0]+"' class='select-style' >"+values[i][1]+"</li>";
                    selected_str += "<li data-value='"+values[i][0]+"' class='select-style' >"+values[i][1]+"</li>";
                }else {
                    str += "<li data-value='"+values[i][0]+"'>"+values[i][1]+"</li>";
                }
            }




            if (! this.get("effective_readonly")) {
                this.$el.find(".category-ul").html(str);
                this.$el.find('.category-ul li').on("click", function(){
                    $(this).addClass("select-style");
                    self.set_value([parseInt($(this).attr("data-value")), $(this).text()]);
                });
            }

            if ( this.get("effective_readonly")) {
                this.$el.find(".category-ul").html(selected_str);
            }



        },

        set_value: function(value_) {
            value_ = value_ === null ? false : value_;
            value_ = value_ instanceof Array ? value_[0] : value_;
            this._super(value_);

        }
    });

//    openerp.web.form.Many2oneForm = openerp.web.form.FieldMany2One.extend({
//        _search_create_popup: function(view, ids, context) {
//            var self = this;
//            var pop = new instance.web.form.SelectCreatePopup(this);
//            var context = this.build_context().eval();
//            var model_obj = new instance.web.Model(this.field.relation);
//            model_obj.call("get_formview_id2", [this.options.view_id],{context:context}).then(function(view_id){
//                console.log(view_id);
//                pop.select_element(
//                self.field.relation,
//                    {
//                        title: (view === 'search' ? _t("Search: ") : _t("Create: ")) + self.string,
//                        initial_ids: ids ? _.map(ids, function(x) {return x[0];}) : undefined,
//                        initial_view: view,
//                        disable_multiple_selection: true,
//                        view_id: view_id
//                    },
//                    self.build_domain(),
//                    new instance.web.CompoundContext(self.build_context(), context || {})
//                );
//                pop.on("elements_selected", self, function(element_ids) {
//                    self.add_id(element_ids[0]);
//                    self.focus();
//                });
//            });
//        }
//    });

    openerp.web.form.widgets.add('many2one_tags', 'instance.web.form.Many2oneTags');
//    openerp.web.form.widgets.add('many2one_form', 'instance.web.form.Many2oneForm');

})();
