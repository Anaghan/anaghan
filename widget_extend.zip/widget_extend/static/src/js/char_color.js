/**
 * Created by mihai on 15-10-22.
 */

(function () {
    openerp.web.form.CharColor = openerp.web.form.FieldChar.extend(openerp.web.form.ReinitializeFieldMixin, {

        template: "CharColor",

        render_value: function() {
            var show_value = this.format_value(this.get('value'), '');
            this.field.size = "30";
            if (!this.get("effective_readonly")) {
                this.$el.find('input').val(show_value);
                this.$el.find('.color').colorPicker({opacity:false});

            } else {
                if (this.password) {
                    show_value = new Array(show_value.length + 1).join('*');
                }
                if(show_value != ''){
                    this.$el.find(".oe_form_char_color_content").css({
                        "display":"inline-block",
                        "height":"20px",
                        "width":"50px",
                        "background":show_value
                    });
                }
            }
        }

    });

    openerp.web.form.widgets.add('char_color', 'instance.web.form.CharColor');
})();