(function() {
var instance = openerp;
instance.web.form.FieldDateYear = instance.web.form.FieldSelection.extend({
    query_values: function() {
        var self = this;
        var def;
        var len = 5;
        var offset = 0;
        if(this.options.len){
        	len = parseInt(this.options.len);
        }
        if(this.options.offset){
        	offset = parseInt(this.options.offset);
        }

		var current_year = new Date().getFullYear();
        var values = [];
        var values_keys = [];
        for(var i=0; i<len; i++) {
        	var item_year = (parseInt(current_year)+offset-i).toString();
        	values.push([item_year, item_year+'年']);
        	values_keys.push(item_year);
        }
		var item_value = [this.get("value"), this.get("value")+'年'];
		if(this.get("value") && values_keys.indexOf(this.get("value"))<0){
			values.push(item_value);
		}
        def = $.when(values);
        this.records_orderer.add(def).then(function(values) {
            if (! _.isEqual(values, self.get("values"))) {
                self.set("values", values);
            }
        });
    }


});

instance.web.form.widgets.add('date_year', 'instance.web.form.FieldDateYear');










})();