/**
 * Created by simo on 15-10-22.
 */
var instance = openerp;
var _t = instance.web._t,
    _lt = instance.web._lt;
var QWeb = instance.web.qweb;
var relation_model = ''
instance.web.DataSet.include({
    name_search: function (name, domain, operator, limit, context, other_domain) {
        //通过定义视图时，options传值过滤记录
        if (other_domain!=null){
            old_model = this._model['name']
            model = this._model
            model['name'] = 'widget.extend'
            return model.call('name_search', {
                name: name || '',
                args: domain || false,
                operator: operator || 'ilike',
                context: this._model.context(),
                limit: limit || 0,
                old_model:old_model,
                other_domain:other_domain
            });
        }else{
            //点击搜索更多时调用
            if(this._model['name'] == 'widget.extend'){
                return this._model.call('name_search', {
                    name: name || '',
                    args: domain || false,
                    operator: operator || 'ilike',
                    context: this._model.context(),
                    limit: limit || 0,
                    old_model:relation_model
                });
            }else{
            //m2m字段调用
                return this._model.call('name_search', {
                    name: name || '',
                    args: domain || false,
                    operator: operator || 'ilike',
                    context: this._model.context(),
                    limit: limit || 0
                });
            }

        }

    }
})

instance.web.form.FieldMany2One.include({
    get_search_result: function(search_val) {
        relation_model = this.field.relation
        var self = this;
        var dataset = new instance.web.DataSet(this, this.field.relation, self.build_context());
        this.last_query = search_val;
        var exclusion_domain = [], ids_blacklist = this.get_search_blacklist();
        if (!_(ids_blacklist).isEmpty()) {
            exclusion_domain.push(['id', 'not in', ids_blacklist]);
        }
        var other_domain = []
        if ('fields' in this.options){
            for (field in this.options['fields']){
                other_domain.push([this.options['fields'][field],'ilike',search_val])
            }
        }
        return this.orderer.add(dataset.name_search(
            search_val, new instance.web.CompoundDomain(self.build_domain(), exclusion_domain),
            'ilike', this.limit + 1, self.build_context(), other_domain)).then(function(data) {
            self.last_search = data;
            // possible selections for the m2o
            var values = _.map(data, function(x) {
                x[1] = x[1].split("\n")[0];
                return {
                    label: _.str.escapeHTML(x[1]),
                    value: x[1],
                    name: x[1],
                    id: x[0]
                };
            });
            // search more... if more results that max
            if (values.length > self.limit) {
                values = values.slice(0, self.limit);
                values.push({
                    label: _t("Search More..."),
                    action: function() {
                        dataset.name_search(search_val, self.build_domain(), 'ilike', 160).done(function(data) {
                            self._search_create_popup("search", data);
                        });
                    },
                    classname: 'oe_m2o_dropdown_option'
                });
            }

            // quick create
            self.options.no_quick_create = true;
            var raw_result = _(data.result).map(function(x) {return x[1];});
            if (search_val.length > 0 && !_.include(raw_result, search_val) &&
                ! (self.options && (self.options.no_create || self.options.no_quick_create))) {
                values.push({
                    label: _.str.sprintf(_t('Create "<strong>%s</strong>"'),
                        $('<span />').text(search_val).html()),
                    action: function() {
                        self._quick_create(search_val);
                    },
                    classname: 'oe_m2o_dropdown_option'
                });
            }
            // create...
            if (!(self.options && (self.options.no_create || self.options.no_create_edit))){
                if(self.options.qx_create){
                values.push({
                    label: _t("新建"),
                    action: function() {
                        self._search_create_popup("form", undefined, self._create_context(search_val));
                    },
                    classname: 'oe_m2o_dropdown_option'
                })
                }else{

                values.push({
                    label: _t("Create and Edit..."),
                    action: function() {
                        self._search_create_popup("form", undefined, self._create_context(search_val));
                    },
                    classname: 'oe_m2o_dropdown_option'
                })
                };
            }
            else if (values.length == 0)
                values.push({
                    label: _t("No results to show..."),
                    action: function() {},
                    classname: 'oe_m2o_dropdown_option'
                });

            return values;
        });
    },

    render_editable: function() {
        var self = this;
        this.$input = this.$el.find("input");

        this.init_error_displayer();

        self.$input.on('focus', function() {
            self.hide_error_displayer();
        });

        this.$drop_down = this.$el.find(".oe_m2o_drop_down_button");
        this.$follow_button = $(".oe_m2o_cm_button", this.$el);

        this.$follow_button.click(function(ev) {
            ev.preventDefault();
            if (!self.get('value')) {
                self.focus();
                return;
            }
            var pop = new instance.web.form.FormOpenPopup(self);
            var context = self.build_context().eval();
            var model_obj = new instance.web.Model(self.field.relation);
            model_obj.call('get_formview_id', [self.get("value"), context]).then(function(view_id){
                var readonly = self.options.readonly ? true : false;
                pop.show_element(
                    self.field.relation,
                    self.get("value"),
                    self.build_context(),
                    {
                        title: _t("Open: ") + self.string,
                        view_id: view_id,
                        readonly: readonly
                    }
                );
                pop.on('write_completed', self, function(){
                    self.display_value = {};
                    self.display_value_backup = {};
                    self.render_value();
                    self.focus();
                    self.trigger('changed_value');
                });
            });
        });

        // some behavior for input
        var input_changed = function() {
            if (self.current_display !== self.$input.val()) {
                self.current_display = self.$input.val();
                if (self.$input.val() === "") {
                    self.internal_set_value(false);
                    self.floating = false;
                } else {
                    self.floating = true;
                }
            }
        };
        this.$input.keydown(input_changed);
        this.$input.change(input_changed);
        this.$drop_down.click(function() {
            self.$input.focus();
            if (self.$input.autocomplete("widget").is(":visible")) {
                self.$input.autocomplete("close");
            } else {
                if (self.get("value") && ! self.floating) {
                    self.$input.autocomplete("search", "");
                } else {
                    self.$input.autocomplete("search");
                }
            }
        });

        // Autocomplete close on dialog content scroll
        var close_autocomplete = _.debounce(function() {
            if (self.$input.autocomplete("widget").is(":visible")) {
                self.$input.autocomplete("close");
            }
        }, 50);
        this.$input.closest(".modal .modal-content").on('scroll', this, close_autocomplete);

        self.ed_def = $.Deferred();
        self.uned_def = $.Deferred();
        var ed_delay = 200;
        var ed_duration = 15000;
        var anyoneLoosesFocus = function (e) {
            if (self.ignore_focusout) { return; }
            var used = false;
            if (self.floating) {
                if (self.last_search.length > 0) {
                    if (self.last_search[0][0] != self.get("value")) {
                        self.display_value = {};
                        self.display_value_backup = {};
                        self.display_value["" + self.last_search[0][0]] = self.last_search[0][1];
                        self.reinit_value(self.last_search[0][0]);
                        self.last_search = []
                    } else {
                        used = true;
                        self.render_value();
                    }
                } else {
                    used = true;
                }
                self.floating = false;
            }
            if (used && self.get("value") === false && ! self.no_ed && ! (self.options && (self.options.no_create || self.options.no_quick_create))) {
                self.ed_def.reject();
                self.uned_def.reject();
                self.ed_def = $.Deferred();
                self.ed_def.done(function() {
                    self.show_error_displayer();
                    ignore_blur = false;
                    self.trigger('focused');
                });
                ignore_blur = true;
                setTimeout(function() {
                    self.ed_def.resolve();
                    self.uned_def.reject();
                    self.uned_def = $.Deferred();
                    self.uned_def.done(function() {
                        self.hide_error_displayer();
                    });
                    setTimeout(function() {self.uned_def.resolve();}, ed_duration);
                }, ed_delay);
            } else {
                self.no_ed = false;
                self.ed_def.reject();
            }
        };
        var ignore_blur = false;
        this.$input.on({
            focusout: anyoneLoosesFocus,
            focus: function () { self.trigger('focused'); },
            autocompleteopen: function () { ignore_blur = true; },
            autocompleteclose: function () { setTimeout(function() {ignore_blur = false;},0); },
            blur: function () {
                // autocomplete open
                if (ignore_blur) { $(this).focus(); return; }
                if (_(self.getChildren()).any(function (child) {
                    return child instanceof instance.web.form.AbstractFormPopup;
                })) { return; }
                self.trigger('blurred');
            }
        });

        var isSelecting = false;
        // autocomplete
        this.$input.autocomplete({
            source: function(req, resp) {
                self.get_search_result(req.term).done(function(result) {
                    resp(result);
                });
            },
            select: function(event, ui) {
                isSelecting = true;
                var item = ui.item;
                if (item.id) {
                    self.display_value = {};
                    self.display_value_backup = {};
                    self.display_value["" + item.id] = item.name;
                    self.reinit_value(item.id);
                } else if (item.action) {
                    item.action();
                    // Cancel widget blurring, to avoid form blur event
                    self.trigger('focused');
                    return false;
                }
            },
            focus: function(e, ui) {
                e.preventDefault();
            },
            html: true,
            // disabled to solve a bug, but may cause others
            //close: anyoneLoosesFocus,
            minLength: 0,
            delay: 200,
        });
        var appendTo = this.$el.parents('.oe_view_manager_body:visible, .modal-dialog:visible').last();
        if (appendTo.length === 0){
            appendTo = '.oe_application > *:visible:last';
        }
        this.$input.autocomplete({
            appendTo: appendTo
        });
        // set position for list of suggestions box
        this.$input.autocomplete( "option", "position", { my : "left top", at: "left bottom" } );
        this.$input.autocomplete("widget").openerpClass();
        // used to correct a bug when selecting an element by pushing 'enter' in an editable list
        this.$input.keyup(function(e) {
            if (e.which === 13) { // ENTER
                if (isSelecting)
                    e.stopPropagation();
            }
            isSelecting = false;
        });
        this.setupFocus(this.$follow_button);
    },
    _search_create_popup: function(view, ids, context) {
        if(!this.options.view_id) {
            return this._super.apply(this, arguments);
        }

        var self = this;
        var pop = new instance.web.form.SelectCreatePopup(this);
        var context = this.build_context().eval();
        var model_obj = new instance.web.Model(this.field.relation);
        model_obj.call("get_formview_id2", [this.options.view_id],{context:context}).then(function(view_id){
            console.log(view_id);
            pop.select_element(
            self.field.relation,
                {
                    title: (view === 'search' ? _t("Search: ") : _t("Create: ")) + self.string,
                    initial_ids: ids ? _.map(ids, function(x) {return x[0];}) : undefined,
                    initial_view: view,
                    disable_multiple_selection: true,
                    view_id: view_id
                },
                self.build_domain(),
                new instance.web.CompoundContext(self.build_context(), context || {})
            );
            pop.on("elements_selected", self, function(element_ids) {
                self.add_id(element_ids[0]);
                self.focus();
            });
        });
    }






});




