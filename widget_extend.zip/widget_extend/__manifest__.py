# -*- coding: utf-8 -*-
{
    'name': "Widget Extend",

    'summary': """
        odoo窗口部件扩展""",

    'description': """
    """,

    'author': "Feitas",
    'website': "http://www.wffeitas.com",
    'category': 'feitas',
    'version': '0.1',
    'depends': ['web'],
    'data': [
        'views/webclient.xml',
    ],
    'qweb' : [
        "static/src/xml/*.xml",
    ],
    'demo': [
    ],
    'installable': True,
    'auto_install': False,
}