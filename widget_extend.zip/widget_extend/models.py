from odoo import models, fields, api
from odoo.osv.expression import get_unaccent_wrapper

class widget_extend(models.Model):
    _name = "widget.extend"

    @api.model
    def name_search(self, name, args=None, operator='ilike', limit=100, old_model = '', other_domain = []):
        if not args:
            args = []
        print 'args----------->',args
        if name and operator in ('=', 'ilike', '=ilike', 'like', '=like'):
            if operator in ('=ilike', '=like'):
                operator = operator[1:]
            if name:
                domain = [('name',operator,name)]
            else:
                domain = [('name',operator,'')]
            if other_domain:
                for od in other_domain:
                    domain = ['|'] + domain + [tuple(od)]
            domain = args + domain
            ids = self.env[old_model].search(domain)

            if ids:
                return self.env[old_model].name_get()
            else:
                return []
        return self.env[old_model].name_search(name, args, operator=operator, limit=limit)

